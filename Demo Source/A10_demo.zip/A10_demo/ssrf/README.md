# Server Side Request Forgery (SSRF)
# Demo OWASP A10

### Cách chạy demo
1. Tải và chạy docker
2. Chuyển hướng đến nơi lưu trữ repo và tạo image
    `docker build -t owasp-ssrf .`
3. Chạy image trong docker container
 	`docker run -d -p 5000:5000 owasp-ssrf`
4. Mở website được host ở `http://127.0.0.1`

### Cách dừng + xóa container và image
1. Tìm container id
`docker ps`
2. Dừng docker container
`docker stop <container id>`
3. Xóa container
`docker rm <container id>`
4. Xóa image
`docker rmi owasp-ssrf`
