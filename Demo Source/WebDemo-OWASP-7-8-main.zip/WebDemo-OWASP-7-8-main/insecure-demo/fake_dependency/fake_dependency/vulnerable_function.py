def vulnerable_function():
    return "This is a malicious dependency!"
