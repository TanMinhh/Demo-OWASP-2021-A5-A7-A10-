# malicious.py
import os
os.system("echo This is a malicious script!")
