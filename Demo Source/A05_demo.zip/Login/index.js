const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const session = require('express-session');
const authRoutes = require('./routes/authRoutes');
const helmet = require('helmet'); // Import helmet

const app = express();
app.use(express.json());

// Sử dụng helmet trước khi phục vụ nội dung tĩnh
app.use(helmet({
    frameguard: { action: 'deny' } // Thiết lập X-Frame-Options: DENY
}));

// Phục vụ nội dung tĩnh (đặt sau helmet)
app.use(express.static(path.join(__dirname, 'public')));

// Các cấu hình khác
mongoose.connect('mongodb://localhost:27017/your_database_name', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log("Connected to MongoDB");
}).catch(err => console.log(err));

app.use(session({
    secret: 'your_secret_key',
    resave: false,
    saveUninitialized: false,
}));

app.use('/auth', authRoutes);

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
