// Thêm sự kiện cho các nút và liên kết chuyển đổi form
document.getElementById("login-btn").addEventListener("click", login);
document.getElementById("register-btn").addEventListener("click", register);
document.getElementById("toggle-link-login").addEventListener("click", toggleForms);
document.getElementById("toggle-link-register").addEventListener("click", toggleForms);

function toggleForms() {
    const loginContainer = document.getElementById("login-container");
    const registerContainer = document.getElementById("register-container");
    if (loginContainer.style.display === "none") {
        loginContainer.style.display = "block";
        registerContainer.style.display = "none";
    } else {
        loginContainer.style.display = "none";
        registerContainer.style.display = "block";
    }
}

async function login() {
    const username = document.getElementById("login-username").value;
    const password = document.getElementById("login-password").value;

    const response = await fetch('/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
    });

    if (response.ok) {
        alert('Login successful!');
    } else {
        alert('Login failed. Please check your credentials.');
    }
}

async function register() {
    const username = document.getElementById("register-username").value;
    const password = document.getElementById("register-password").value;

    const response = await fetch('/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
    });

    if (response.ok) {
        alert('Registration successful! Please login.');
        toggleForms();
    } else {
        alert('Registration failed. Please try again.');
    }
}
